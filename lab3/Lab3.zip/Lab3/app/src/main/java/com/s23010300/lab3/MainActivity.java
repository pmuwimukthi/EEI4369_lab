package com.s23010300.lab3;

import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast; // For user feedback

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap myMap;
    private EditText editTextLocation;
    private Button buttonSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        editTextLocation = findViewById(R.id.editTextLocation);
        buttonSearch = findViewById(R.id.buttonSearch);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        buttonSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchLocation();
            }
        });
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        myMap = googleMap;
        LatLng defaultLocation = new LatLng(6.917366739184529, 79.88292981678214);
        myMap.addMarker(new MarkerOptions().position(defaultLocation).title("Open University"));
        myMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, 12.0f));
        myMap.getUiSettings().setZoomGesturesEnabled(true);
        myMap.getUiSettings().setZoomControlsEnabled(true);
    }

    private void searchLocation() {
        String locationName = editTextLocation.getText().toString().trim();
        if (locationName.isEmpty()) {
            Toast.makeText(this, "Please enter a location", Toast.LENGTH_SHORT).show();
            return;
        }

        if (myMap == null) {
            Toast.makeText(this, "Map is not ready yet", Toast.LENGTH_SHORT).show();
            return;
        }

        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addressList = geocoder.getFromLocationName(locationName, 1);

            if (addressList != null && !addressList.isEmpty()) {
                Address address = addressList.get(0);
                LatLng latLng = new LatLng(address.getLatitude(), address.getLongitude());

                myMap.clear();

                myMap.addMarker(new MarkerOptions().position(latLng).title(locationName));

                myMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15.0f));

                Toast.makeText(this, "Location found: " + address.getAddressLine(0), Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Location not found. Try a more specific name.", Toast.LENGTH_LONG).show();
            }
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error finding location. Check your network connection.", Toast.LENGTH_LONG).show();
        }
    }
}
